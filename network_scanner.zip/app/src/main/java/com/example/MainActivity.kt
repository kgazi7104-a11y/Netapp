package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.SettingsEthernet
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.Room
import com.example.data.AppDatabase
import com.example.data.ScanHistory
import com.example.data.ScanHistoryRepository
import com.example.ui.theme.GreenTerminal
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.OrangeOrange
import com.example.ui.theme.RedWarning
import com.example.ui.theme.SlateBackground
import com.example.ui.theme.SlatePrimary
import com.example.ui.theme.SlateSurface
import com.example.viewmodel.NetworkScanViewModel
import com.example.viewmodel.NetworkScanViewModelFactory
import com.example.viewmodel.PortMode
import com.example.viewmodel.PortResult
import com.example.viewmodel.PortStatus
import com.example.viewmodel.STANDARD_PORTS
import com.example.viewmodel.ScanUiState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var database: AppDatabase
    private lateinit var repository: ScanHistoryRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Initialize Room DB
        database = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "port_checker_database"
        ).fallbackToDestructiveMigration().build()
        
        repository = ScanHistoryRepository(database.scanHistoryDao())

        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val factory = remember { NetworkScanViewModelFactory(repository) }
                val viewModel: NetworkScanViewModel = viewModel(factory = factory)
                
                PortCheckerApp(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PortCheckerApp(viewModel: NetworkScanViewModel) {
    val targetInput by viewModel.targetInput.collectAsState()
    val portMode by viewModel.portMode.collectAsState()
    val customPortsInput by viewModel.customPortsInput.collectAsState()
    val selectedCommonPorts by viewModel.selectedCommonPorts.collectAsState()
    val timeoutMs by viewModel.timeoutInput.collectAsState()
    val uiState by viewModel.uiState.collectAsState()
    val inputWarning by viewModel.inputWarning.collectAsState()
    val scanHistory by viewModel.scanHistory.collectAsState()

    val keyboardController = LocalSoftwareKeyboardController.current

    // For viewing a historic item's detail dialog
    var selectedHistoryItem by remember { mutableStateOf<ScanHistory?>(null) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageOfNetworkCheck(),
                            contentDescription = "Diagnostics Icon",
                            tint = SlatePrimary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "PORT DIAGNOSTIC CHECKER",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SlateBackground,
                    titleContentColor = Color.White
                )
            )
        },
        containerColor = SlateBackground
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            
            // Header Description / Banner
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = SlateSurface),
                    shape = RoundedCornerShape(12.dp),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(SlatePrimary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Router,
                                contentDescription = "Router Service",
                                tint = SlatePrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(
                                text = "Secure Network Utility",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Text(
                                text = "Resolve hostnames and check connectivity state across predefined common service endpoints or user-defined custom ports.",
                                color = Color.LightGray,
                                fontSize = 12.sp,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }
            }

            // Input Configuration card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = SlateSurface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "DIAGNOSTIC TARGET",
                            color = SlatePrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        // Host IP / Domain field
                        OutlinedTextField(
                            value = targetInput,
                            onValueChange = { viewModel.onTargetInputChange(it) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("target_host_input"),
                            placeholder = { Text("e.g. 192.168.1.1 or google.com", color = Color.Gray) },
                            label = { Text("Host IP or Domain Name", color = SlatePrimary) },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Dns,
                                    contentDescription = "DNS Host",
                                    tint = SlatePrimary
                                )
                            },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SlatePrimary,
                                unfocusedBorderColor = Color.Gray.copy(alpha = 0.5f),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Uri,
                                imeAction = ImeAction.Done
                            ),
                            keyboardActions = KeyboardActions(
                                onDone = {
                                    keyboardController?.hide()
                                    viewModel.startScan()
                                }
                            )
                        )

                        // Input validation warning
                        AnimatedVisibility(visible = inputWarning != null) {
                            Column {
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(
                                            RedWarning.copy(alpha = 0.1f),
                                            RoundedCornerShape(4.dp)
                                        )
                                        .padding(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = "Warning",
                                        tint = RedWarning,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = inputWarning ?: "",
                                        color = RedWarning,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Tab for Mode Selection
                        Text(
                            text = "PORT SELECTION MODE",
                            color = SlatePrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        PortModeTabs(
                            currentMode = portMode,
                            onModeSelected = { viewModel.onPortModeChange(it) }
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Conditional options based on Mode
                        if (portMode == PortMode.COMMON) {
                            CommonPortsSelector(
                                selectedPorts = selectedCommonPorts,
                                onPortToggled = { viewModel.toggleCommonPort(it) }
                            )
                        } else {
                            CustomPortsInput(
                                customInput = customPortsInput,
                                onInputChange = { viewModel.onCustomPortsChange(it) }
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Connection Timeout Slider
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Timer,
                                    contentDescription = "Timer",
                                    tint = Color.LightGray,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Handshake Timeout",
                                    color = Color.LightGray,
                                    fontSize = 13.sp
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Button(
                                    onClick = { viewModel.onTimeoutChange(500) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (timeoutMs == 500) SlatePrimary else Color.Gray.copy(alpha = 0.2f),
                                        contentColor = if (timeoutMs == 500) Color.Black else Color.White
                                    ),
                                    modifier = Modifier.height(28.dp),
                                    contentPadding = RowDefaultsButtonsPadding()
                                ) {
                                    Text("500ms", fontSize = 11.sp)
                                }
                                Spacer(modifier = Modifier.width(4.dp))
                                Button(
                                    onClick = { viewModel.onTimeoutChange(1500) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (timeoutMs == 1500) SlatePrimary else Color.Gray.copy(alpha = 0.2f),
                                        contentColor = if (timeoutMs == 1500) Color.Black else Color.White
                                    ),
                                    modifier = Modifier.height(28.dp),
                                    contentPadding = RowDefaultsButtonsPadding()
                                ) {
                                    Text("1.5s", fontSize = 11.sp)
                                }
                                Spacer(modifier = Modifier.width(4.dp))
                                Button(
                                    onClick = { viewModel.onTimeoutChange(3000) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (timeoutMs == 3000) SlatePrimary else Color.Gray.copy(alpha = 0.2f),
                                        contentColor = if (timeoutMs == 3000) Color.Black else Color.White
                                    ),
                                    modifier = Modifier.height(28.dp),
                                    contentPadding = RowDefaultsButtonsPadding()
                                ) {
                                    Text("3s", fontSize = 11.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Scan Actions Button
                        val isScanning = uiState is ScanUiState.Scanning || uiState is ScanUiState.Loading
                        Button(
                            onClick = {
                                keyboardController?.hide()
                                if (isScanning) {
                                    viewModel.cancelScan()
                                } else {
                                    viewModel.startScan()
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("scan_trigger_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isScanning) RedWarning else SlatePrimary,
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = if (isScanning) Icons.Default.Cancel else Icons.Default.PlayArrow,
                                    contentDescription = if (isScanning) "Cancel Scan" else "Start Scan",
                                    tint = Color.Black,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isScanning) "ABORT SYSTEM SCAN" else "TRIGGER SYSTEM DIAGNOSTICS",
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                            }
                        }
                    }
                }
            }

            // Diagnostic running / result outputs
            item {
                AnimatedVisibility(
                    visible = uiState != ScanUiState.Idle,
                    enter = fadeIn() + slideInVertically(),
                    exit = fadeOut()
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "DIAGNOSTIC CONSOLE FEED",
                            color = SlatePrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            letterSpacing = 1.2.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = SlateSurface),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp)
                            ) {
                                when (val state = uiState) {
                                    is ScanUiState.Loading -> {
                                        Text(
                                            text = "Resolving Address: ${state.host}",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = state.step,
                                            color = Color.LightGray,
                                            fontSize = 12.sp
                                        )
                                        Spacer(modifier = Modifier.height(16.dp))
                                        LinearProgressIndicator(
                                            modifier = Modifier.fillMaxWidth(),
                                            color = SlatePrimary,
                                            trackColor = Color.Gray.copy(alpha = 0.2f)
                                        )
                                    }

                                    is ScanUiState.Scanning -> {
                                        val percent = if (state.totalPorts > 0) {
                                            (state.currentPortIndex.toFloat() / state.totalPorts.toFloat())
                                        } else {
                                            0f
                                        }
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(
                                                    text = "Scanning ${state.host}",
                                                    color = Color.White,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 14.sp
                                                )
                                                Text(
                                                    text = "Resolved IP: ${state.ipAddress}",
                                                    color = Color.Gray,
                                                    fontSize = 11.sp
                                                )
                                            }
                                            Text(
                                                text = "${state.currentPortIndex}/${state.totalPorts} Ports Checked",
                                                color = SlatePrimary,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(12.dp))
                                        LinearProgressIndicator(
                                            progress = percent,
                                            modifier = Modifier.fillMaxWidth(),
                                            color = SlatePrimary,
                                            trackColor = Color.Gray.copy(alpha = 0.2f)
                                        )
                                        Spacer(modifier = Modifier.height(16.dp))

                                        TerminalPortConsoleList(results = state.completedResults)
                                    }

                                    is ScanUiState.Success -> {
                                        DiagnosticSummaryHeader(
                                            host = state.host,
                                            ip = state.ipAddress,
                                            durationMs = state.durationMs,
                                            openCount = state.openPortsCount,
                                            total = state.results.size
                                        )
                                        Spacer(modifier = Modifier.height(16.dp))
                                        TerminalPortConsoleList(results = state.results)
                                    }

                                    is ScanUiState.Error -> {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(
                                                    RedWarning.copy(alpha = 0.1f),
                                                    RoundedCornerShape(8.dp)
                                                )
                                                .border(
                                                    1.dp,
                                                    RedWarning.copy(alpha = 0.2f),
                                                    RoundedCornerShape(8.dp)
                                                )
                                                .padding(16.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.ErrorOutline,
                                                contentDescription = "Error icon",
                                                tint = RedWarning,
                                                modifier = Modifier.size(24.dp)
                                            )
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column {
                                                Text(
                                                    text = "CONNECTION ATTEMPT FAILED",
                                                    color = RedWarning,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 12.sp
                                                )
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(
                                                    text = state.message,
                                                    color = Color.LightGray,
                                                    fontSize = 13.sp,
                                                    lineHeight = 18.sp
                                                )
                                            }
                                        }
                                    }

                                    else -> {}
                                }
                            }
                        }
                    }
                }
            }

            // Scan history section
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "History Logs",
                            tint = Color.LightGray,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "DIAGNOSTIC LOG ARCHIVES",
                            color = Color.LightGray,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            letterSpacing = 1.2.sp
                        )
                    }
                    if (scanHistory.isNotEmpty()) {
                        IconButton(
                            onClick = { viewModel.clearAllHistory() },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ClearAll,
                                contentDescription = "Clear All Archives",
                                tint = RedWarning,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
            }

            if (scanHistory.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(SlateSurface, RoundedCornerShape(12.dp))
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.CloudQueue,
                            contentDescription = "No archives",
                            tint = Color.Gray,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No Previous Diagnostic Runs Found",
                            color = Color.LightGray,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Trigger a system scan or input target credentials to begin collecting diagnostic summaries.",
                            color = Color.Gray,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            lineHeight = 16.sp
                        )
                    }
                }
            } else {
                items(scanHistory) { historyItem ->
                    HistoryItemRow(
                        item = historyItem,
                        onRowClick = { selectedHistoryItem = historyItem },
                        onDeleteClick = { viewModel.deleteHistoryItem(historyItem.id) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }

    // Detail Dialog for selected historic runs
    selectedHistoryItem?.let { item ->
        val results = remember(item.serializedResults) {
            NetworkScanViewModel.deserializePortResults(item.serializedResults)
        }
        HistoryDetailDialog(
            item = item,
            results = results,
            onDismiss = { selectedHistoryItem = null }
        )
    }
}

@Composable
fun PortModeTabs(
    currentMode: PortMode,
    onModeSelected: (PortMode) -> Unit
) {
    val modes = listOf(PortMode.COMMON, PortMode.CUSTOM)
    val selectedIndex = modes.indexOf(currentMode)

    TabRow(
        selectedTabIndex = selectedIndex,
        containerColor = Color.Black.copy(alpha = 0.2f),
        contentColor = SlatePrimary,
        indicator = { tabPositions ->
            TabRowDefaults.Indicator(
                Modifier.tabIndicatorOffset(tabPositions[selectedIndex]),
                color = SlatePrimary,
                height = 2.dp
            )
        },
        divider = {
            Divider(color = Color.Gray.copy(alpha = 0.2f))
        },
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
    ) {
        modes.forEachIndexed { index, mode ->
            Tab(
                selected = selectedIndex == index,
                onClick = { onModeSelected(mode) },
                text = {
                    Text(
                        text = if (mode == PortMode.COMMON) "Standard Common Services" else "Custom Port Ranges",
                        fontWeight = if (selectedIndex == index) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 12.sp
                    )
                }
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CommonPortsSelector(
    selectedPorts: Set<Int>,
    onPortToggled: (Int) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "Select targets to scan (services matching standard IP configurations):",
            color = Color.LightGray,
            fontSize = 12.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            STANDARD_PORTS.forEach { (port, name) ->
                val isSelected = selectedPorts.contains(port)
                val borderCol by animateColorAsState(if (isSelected) SlatePrimary else Color.Gray.copy(alpha = 0.3f))
                val bgCol by animateColorAsState(if (isSelected) SlatePrimary.copy(alpha = 0.1f) else Color.Transparent)
                val textCol by animateColorAsState(if (isSelected) SlatePrimary else Color.LightGray)

                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(bgCol)
                        .border(1.dp, borderCol, RoundedCornerShape(4.dp))
                        .clickable { onPortToggled(port) }
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Port $port ($name)",
                        fontSize = 11.sp,
                        color = textCol,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }
    }
}

@Composable
fun CustomPortsInput(
    customInput: String,
    onInputChange: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "Enter a comma-separated list of numeric TCP ports (1 - 65535):",
            color = Color.LightGray,
            fontSize = 12.sp,
            modifier = Modifier.padding(bottom = 6.dp)
        )
        OutlinedTextField(
            value = customInput,
            onValueChange = onInputChange,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("custom_ports_input_field"),
            placeholder = { Text("e.g. 21, 22, 80, 443, 3306, 8080", color = Color.Gray) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = SlatePrimary,
                unfocusedBorderColor = Color.Gray.copy(alpha = 0.4f),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            ),
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Number,
                imeAction = ImeAction.Done
            )
        )
    }
}

@Composable
fun TerminalPortConsoleList(results: List<PortResult>) {
    if (results.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("Waiting for network ping...", color = Color.Gray, fontSize = 12.sp)
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.Black.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
            .border(1.dp, Color.Gray.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
            .padding(8.dp)
            .heightIn(max = 240.dp)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(results) { res ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        val statusSymbolColor = when (res.status) {
                            PortStatus.OPEN -> GreenTerminal
                            PortStatus.CLOSED -> RedWarning
                            PortStatus.TIMEOUT -> OrangeOrange
                            PortStatus.FAILED -> Color.LightGray
                        }
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(statusSymbolColor)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "PORT ${res.port}",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = res.serviceName,
                            color = Color.Gray,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = res.status.name,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = when (res.status) {
                                PortStatus.OPEN -> GreenTerminal
                                PortStatus.CLOSED -> RedWarning
                                PortStatus.TIMEOUT -> OrangeOrange
                                PortStatus.FAILED -> Color.LightGray
                            }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "${res.latencyMs}ms",
                            color = Color.LightGray,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DiagnosticSummaryHeader(
    host: String,
    ip: String,
    durationMs: Long,
    openCount: Int,
    total: Int
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(SlatePrimary.copy(alpha = 0.05f), RoundedCornerShape(8.dp))
            .border(1.dp, SlatePrimary.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = host,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Text(
                    text = "IP Address: $ip",
                    color = Color.Gray,
                    fontSize = 12.sp
                )
            }
            Row(
                modifier = Modifier
                    .background(
                        if (openCount > 0) GreenTerminal.copy(alpha = 0.15f) else Color.Gray.copy(alpha = 0.15f),
                        RoundedCornerShape(4.dp)
                    )
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (openCount > 0) Icons.Default.CheckCircle else Icons.Default.Info,
                    contentDescription = "Diagnostic Outcome",
                    tint = if (openCount > 0) GreenTerminal else Color.Gray,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "$openCount OPEN / $total CHECKED",
                    color = if (openCount > 0) GreenTerminal else Color.LightGray,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        Divider(color = Color.Gray.copy(alpha = 0.15f))
        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Diagnostics completed.",
                color = Color.LightGray,
                fontSize = 12.sp
            )
            Text(
                text = "Latency check: ${durationMs}ms",
                color = SlatePrimary,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HistoryItemRow(
    item: ScanHistory,
    onRowClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val dateString = remember(item.timestamp) {
        val sdf = SimpleDateFormat("MMM dd, yyyy HH:mm:ss", Locale.getDefault())
        sdf.format(Date(item.timestamp))
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick = onRowClick,
                onLongClick = onRowClick
            ),
        colors = CardDefaults.cardColors(containerColor = SlateSurface.copy(alpha = 0.8f)),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(
                            if (item.openPortsCount > 0) GreenTerminal.copy(alpha = 0.1f) else Color.Gray.copy(
                                alpha = 0.1f
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (item.openPortsCount > 0) Icons.Default.CheckCircle else Icons.Default.SettingsEthernet,
                        contentDescription = "Status",
                        tint = if (item.openPortsCount > 0) GreenTerminal else Color.Gray,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = item.host,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "IP: ${item.ipAddress} • $dateString",
                        color = Color.Gray,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(
                    horizontalAlignment = Alignment.End,
                    modifier = Modifier.padding(end = 8.dp)
                ) {
                    Text(
                        text = "${item.openPortsCount} Open",
                        color = if (item.openPortsCount > 0) GreenTerminal else Color.LightGray,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Text(
                        text = "${item.durationMs}ms",
                        color = Color.Gray,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp
                    )
                }
                IconButton(
                    onClick = onDeleteClick,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete run",
                        tint = RedWarning.copy(alpha = 0.7f),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryDetailDialog(
    item: ScanHistory,
    results: List<PortResult>,
    onDismiss: () -> Unit
) {
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            colors = CardDefaults.cardColors(containerColor = SlateSurface),
            shape = RoundedCornerShape(12.dp),
            border = borderOfCard(SlatePrimary.copy(alpha = 0.3f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "HISTORIC RUN LOG",
                        color = SlatePrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        letterSpacing = 1.sp
                    )
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Cancel,
                            contentDescription = "Dismiss",
                            tint = Color.Gray,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = item.host,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                Text(
                    text = "IP: ${item.ipAddress}",
                    color = Color.LightGray,
                    fontSize = 12.sp
                )

                Spacer(modifier = Modifier.height(12.dp))
                Divider(color = Color.Gray.copy(alpha = 0.15f))
                Spacer(modifier = Modifier.height(12.dp))

                // Detail statistics
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Duration", color = Color.Gray, fontSize = 11.sp)
                        Text("${item.durationMs}ms", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Column {
                        Text("Open Ports", color = Color.Gray, fontSize = 11.sp)
                        Text("${item.openPortsCount}", color = if (item.openPortsCount > 0) GreenTerminal else Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Column {
                        Text("Total Checked", color = Color.Gray, fontSize = 11.sp)
                        Text("${item.totalPortsChecked}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "PORT RESULTS FEED:",
                    color = Color.Gray,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
                Spacer(modifier = Modifier.height(6.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 200.dp)
                        .background(Color.Black.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(results) { res ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(CircleShape)
                                            .background(
                                                when (res.status) {
                                                    PortStatus.OPEN -> GreenTerminal
                                                    PortStatus.CLOSED -> RedWarning
                                                    PortStatus.TIMEOUT -> OrangeOrange
                                                    PortStatus.FAILED -> Color.LightGray
                                                }
                                            )
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Port ${res.port}",
                                        color = Color.White,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = res.serviceName,
                                        color = Color.Gray,
                                        fontSize = 11.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Text(
                                    text = res.status.name,
                                    color = when (res.status) {
                                        PortStatus.OPEN -> GreenTerminal
                                        PortStatus.CLOSED -> RedWarning
                                        PortStatus.TIMEOUT -> OrangeOrange
                                        PortStatus.FAILED -> Color.LightGray
                                    },
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = SlatePrimary, contentColor = Color.Black),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("CLOSE REPORT", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// Helper methods to bypass missing icons/modifiers gracefully to build successfully
private fun imageOfNetworkCheck() = Icons.Default.NetworkCheck

private fun RowDefaultsButtonsPadding() = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp)

private fun borderOfCard(color: Color) = androidx.compose.foundation.BorderStroke(1.dp, color)
