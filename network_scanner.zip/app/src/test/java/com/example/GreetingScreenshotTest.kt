package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.data.ScanHistory
import com.example.data.ScanHistoryDao
import com.example.data.ScanHistoryRepository
import com.example.viewmodel.NetworkScanViewModel
import com.example.ui.theme.MyApplicationTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

class FakeScanHistoryDao : ScanHistoryDao {
    override fun getAllHistory(): Flow<List<ScanHistory>> = flowOf(emptyList())
    override suspend fun insertHistory(history: ScanHistory) {}
    override suspend fun deleteHistoryById(id: Int) {}
    override suspend fun clearAllHistory() {}
}

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [34])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun greeting_screenshot() {
    val fakeDao = FakeScanHistoryDao()
    val repo = ScanHistoryRepository(fakeDao)
    val viewModel = NetworkScanViewModel(repo)

    composeTestRule.setContent {
      MyApplicationTheme {
        PortCheckerApp(viewModel = viewModel)
      }
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/greeting.png")
  }
}
