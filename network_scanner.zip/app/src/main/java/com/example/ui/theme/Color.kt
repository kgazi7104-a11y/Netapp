package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light/Dark Slate Palette
val SlatePrimary = Color(0xFF00ADB5)       // Cyber Teal Accent
val SlateSecondary = Color(0xFF393E46)     // Deep Slate Grey
val SlateTertiary = Color(0xFF222831)      // Dark Charcoal
val SlateBackground = Color(0xFF1E2229)    // Terminal Dark Background
val SlateSurface = Color(0xFF2D323F)       // High-contrast Card Surface

val GreenTerminal = Color(0xFF00FF66)      // Success / Port Open Green
val RedWarning = Color(0xFFFF4136)         // Closed / Blocked Port Red
val OrangeOrange = Color(0xFFFF851B)       // Timeout Orange

// Legacy/Compat references
val Purple80 = SlatePrimary
val PurpleGrey80 = Color(0xFF636D7B)
val Pink80 = GreenTerminal

val Purple40 = Color(0xFF00838F)
val PurpleGrey40 = Color(0xFF455A64)
val Pink40 = Color(0xFF388E3C)

