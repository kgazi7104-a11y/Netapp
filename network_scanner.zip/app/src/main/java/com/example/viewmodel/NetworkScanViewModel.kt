package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.ScanHistory
import com.example.data.ScanHistoryRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import kotlin.system.measureTimeMillis

// List of common diagnostic services/ports
val STANDARD_PORTS = mapOf(
    21 to "FTP (File Transfer)",
    22 to "SSH (Secure Shell)",
    23 to "Telnet (Remote Terminal)",
    25 to "SMTP (Email Routing)",
    53 to "DNS (Domain Name Service)",
    80 to "HTTP (Unencrypted Web)",
    110 to "POP3 (Mail Access)",
    143 to "IMAP (Mail Access)",
    443 to "HTTPS (Secure Web Server)",
    445 to "SMB (File Sharing)",
    3306 to "MySQL (Database Server)",
    8080 to "HTTP-Alt (Alternate Web)",
    8443 to "HTTPS-Alt (Secure Web Alt)"
)

data class PortResult(
    val port: Int,
    val serviceName: String,
    val status: PortStatus,
    val latencyMs: Long,
    val details: String = ""
)

enum class PortStatus {
    OPEN,      // Handshake succeeded
    CLOSED,    // Connection refused immediately
    TIMEOUT,   // Port filtered or unreachable
    FAILED     // Generic socket exception
}

enum class PortMode {
    COMMON,
    CUSTOM
}

sealed interface ScanUiState {
    object Idle : ScanUiState
    data class Loading(val host: String, val step: String) : ScanUiState
    data class Scanning(
        val host: String,
        val ipAddress: String,
        val currentPortIndex: Int,
        val totalPorts: Int,
        val completedResults: List<PortResult>
    ) : ScanUiState
    data class Success(
        val host: String,
        val ipAddress: String,
        val durationMs: Long,
        val openPortsCount: Int,
        val results: List<PortResult>
    ) : ScanUiState
    data class Error(val host: String, val message: String) : ScanUiState
}

class NetworkScanViewModel(private val repository: ScanHistoryRepository) : ViewModel() {

    // Target hostname/IP address input
    private val _targetInput = MutableStateFlow("")
    val targetInput: StateFlow<String> = _targetInput.asStateFlow()

    // Port selection mode (Common predefined vs custom user range)
    private val _portMode = MutableStateFlow(PortMode.COMMON)
    val portMode: StateFlow<PortMode> = _portMode.asStateFlow()

    // Comma-separated custom port list
    private val _customPortsInput = MutableStateFlow("22, 80, 443, 8080")
    val customPortsInput: StateFlow<String> = _customPortsInput.asStateFlow()

    // Preselected common ports
    private val _selectedCommonPorts = MutableStateFlow(setOf(22, 80, 443, 8080))
    val selectedCommonPorts: StateFlow<Set<Int>> = _selectedCommonPorts.asStateFlow()

    // Timeout (in milliseconds)
    private val _timeoutInput = MutableStateFlow(1500)
    val timeoutInput: StateFlow<Int> = _timeoutInput.asStateFlow()

    // Scan execution visual state
    private val _uiState = MutableStateFlow<ScanUiState>(ScanUiState.Idle)
    val uiState: StateFlow<ScanUiState> = _uiState.asStateFlow()

    // Validation/Input warnings
    private val _inputWarning = MutableStateFlow<String?>(null)
    val inputWarning: StateFlow<String?> = _inputWarning.asStateFlow()

    // DB Scan history
    val scanHistory: StateFlow<List<ScanHistory>> = repository.allHistory
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun onTargetInputChange(input: String) {
        _targetInput.value = input
        _inputWarning.value = null
    }

    fun onPortModeChange(mode: PortMode) {
        _portMode.value = mode
        _inputWarning.value = null
    }

    fun onCustomPortsChange(ports: String) {
        _customPortsInput.value = ports
        _inputWarning.value = null
    }

    fun toggleCommonPort(port: Int) {
        val current = _selectedCommonPorts.value.toMutableSet()
        if (current.contains(port)) {
            current.remove(port)
        } else {
            current.add(port)
        }
        _selectedCommonPorts.value = current
    }

    fun onTimeoutChange(timeoutMs: Int) {
        _timeoutInput.value = timeoutMs
    }

    fun clearWarning() {
        _inputWarning.value = null
    }

    fun cancelScan() {
        _uiState.value = ScanUiState.Idle
    }

    fun deleteHistoryItem(id: Int) {
        viewModelScope.launch {
            repository.deleteById(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAll()
        }
    }

    fun startScan() {
        val hostToScan = _targetInput.value.trim()
        if (hostToScan.isEmpty()) {
            _inputWarning.value = "Please enter an IP address or domain name."
            return
        }

        val portsToScan = mutableListOf<Pair<Int, String>>()
        if (_portMode.value == PortMode.COMMON) {
            val commonList = _selectedCommonPorts.value.sorted()
            if (commonList.isEmpty()) {
                _inputWarning.value = "Please select at least one port service to check."
                return
            }
            commonList.forEach { port ->
                portsToScan.add(port to (STANDARD_PORTS[port] ?: "Service"))
            }
        } else {
            val customList = _customPortsInput.value.split(",")
                .map { it.trim().toIntOrNull() }
                .filterNotNull()
                .filter { it in 1..65535 }
                .distinct()
                .sorted()
            
            if (customList.isEmpty()) {
                _inputWarning.value = "Please enter a valid comma-separated list of ports (e.g. 22,80,443)"
                return
            }
            customList.forEach { port ->
                portsToScan.add(port to (STANDARD_PORTS[port] ?: "Custom Service"))
            }
        }

        _uiState.value = ScanUiState.Loading(hostToScan, "Resolving DNS and network reachability...")

        viewModelScope.launch {
            try {
                // Perform Hostname/DNS resolution safely on IO
                val resolvedAddress = withContext(Dispatchers.IO) {
                    InetAddress.getByName(hostToScan)
                }
                val ipAddress = resolvedAddress.hostAddress ?: hostToScan

                val results = mutableListOf<PortResult>()
                var openCount = 0
                val timeoutValue = _timeoutInput.value

                _uiState.value = ScanUiState.Scanning(
                    host = hostToScan,
                    ipAddress = ipAddress,
                    currentPortIndex = 0,
                    totalPorts = portsToScan.size,
                    completedResults = emptyList()
                )

                val duration = measureTimeMillis {
                    for (index in portsToScan.indices) {
                        val (port, service) = portsToScan[index]

                        // Check if the scan is still active (not cancelled by returning to Idle)
                        if (_uiState.value !is ScanUiState.Scanning) break

                        _uiState.value = ScanUiState.Scanning(
                            host = hostToScan,
                            ipAddress = ipAddress,
                            currentPortIndex = index,
                            totalPorts = portsToScan.size,
                            completedResults = results.toList()
                        )

                        val result = checkPortConnectivity(ipAddress, port, service, timeoutValue)
                        if (result.status == PortStatus.OPEN) {
                            openCount++
                        }
                        results.add(result)
                    }
                }

                // If scan was canceled mid-way, don't update to success state
                if (_uiState.value !is ScanUiState.Scanning) return@launch

                val historyItem = ScanHistory(
                    host = hostToScan,
                    ipAddress = ipAddress,
                    durationMs = duration,
                    openPortsCount = openCount,
                    totalPortsChecked = portsToScan.size,
                    serializedResults = serializePortResults(results)
                )

                // Persist the scan result to database history
                repository.insert(historyItem)

                _uiState.value = ScanUiState.Success(
                    host = hostToScan,
                    ipAddress = ipAddress,
                    durationMs = duration,
                    openPortsCount = openCount,
                    results = results
                )

            } catch (e: UnknownHostException) {
                _uiState.value = ScanUiState.Error(
                    hostToScan,
                    "Failed to resolve host '$hostToScan'. Ensure your device has an active internet connection and the host is typed correctly."
                )
            } catch (e: Exception) {
                _uiState.value = ScanUiState.Error(
                    hostToScan,
                    "Error occurred during diagnostic check: ${e.localizedMessage ?: "Unknown network exception"}"
                )
            }
        }
    }

    private suspend fun checkPortConnectivity(
        ipAddress: String,
        port: Int,
        serviceName: String,
        timeoutMs: Int
    ): PortResult = withContext(Dispatchers.IO) {
        var socket: Socket? = null
        val start = System.currentTimeMillis()
        try {
            socket = Socket()
            socket.connect(InetSocketAddress(ipAddress, port), timeoutMs)
            val latency = System.currentTimeMillis() - start
            PortResult(port, serviceName, PortStatus.OPEN, latency, "TCP handshake completed.")
        } catch (e: SocketTimeoutException) {
            val latency = System.currentTimeMillis() - start
            PortResult(port, serviceName, PortStatus.TIMEOUT, latency, "No response. Filtered or offline.")
        } catch (e: ConnectException) {
            val latency = System.currentTimeMillis() - start
            PortResult(port, serviceName, PortStatus.CLOSED, latency, "Connection refused (port closed).")
        } catch (e: IOException) {
            val latency = System.currentTimeMillis() - start
            val msg = e.localizedMessage ?: ""
            if (msg.contains("Connection refused", ignoreCase = true)) {
                PortResult(port, serviceName, PortStatus.CLOSED, latency, "Connection refused.")
            } else {
                PortResult(port, serviceName, PortStatus.FAILED, latency, "Unreachable: $msg")
            }
        } catch (e: Exception) {
            val latency = System.currentTimeMillis() - start
            PortResult(port, serviceName, PortStatus.FAILED, latency, e.localizedMessage ?: "Network error.")
        } finally {
            try {
                socket?.close()
            } catch (ignored: Exception) {}
        }
    }

    companion object {
        fun serializePortResults(results: List<PortResult>): String {
            return results.joinToString(";") { r ->
                "${r.port}|${r.serviceName.replace("|", " ")}|${r.status.name}|${r.latencyMs}|${r.details.replace("|", " ").replace(";", " ")}"
            }
        }

        fun deserializePortResults(serialized: String): List<PortResult> {
            if (serialized.isEmpty()) return emptyList()
            return serialized.split(";").mapNotNull { item ->
                val parts = item.split("|")
                if (parts.size >= 4) {
                    val port = parts[0].toIntOrNull() ?: return@mapNotNull null
                    val serviceName = parts[1]
                    val status = try { PortStatus.valueOf(parts[2]) } catch (e: Exception) { PortStatus.FAILED }
                    val latencyMs = parts[3].toLongOrNull() ?: 0L
                    val details = if (parts.size > 4) parts[4] else ""
                    PortResult(port, serviceName, status, latencyMs, details)
                } else {
                    null
                }
            }
        }
    }
}

class NetworkScanViewModelFactory(private val repository: ScanHistoryRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(NetworkScanViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return NetworkScanViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

// Simple exception subclass helper since java.net.ConnectException might need manual import
private typealias ConnectException = java.net.ConnectException
