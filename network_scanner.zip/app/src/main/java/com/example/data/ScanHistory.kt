package com.example.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "scan_history")
data class ScanHistory(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val host: String,
    val ipAddress: String,
    val timestamp: Long = System.currentTimeMillis(),
    val durationMs: Long,
    val openPortsCount: Int,
    val totalPortsChecked: Int,
    // Serialized results in format: port|service|status|latencyMs;...
    val serializedResults: String
)

@Dao
interface ScanHistoryDao {
    @Query("SELECT * FROM scan_history ORDER BY timestamp DESC")
    fun getAllHistory(): Flow<List<ScanHistory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: ScanHistory)

    @Query("DELETE FROM scan_history WHERE id = :id")
    suspend fun deleteHistoryById(id: Int)

    @Query("DELETE FROM scan_history")
    suspend fun clearAllHistory()
}

@Database(entities = [ScanHistory::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun scanHistoryDao(): ScanHistoryDao
}

class ScanHistoryRepository(private val scanHistoryDao: ScanHistoryDao) {
    val allHistory: Flow<List<ScanHistory>> = scanHistoryDao.getAllHistory()

    suspend fun insert(history: ScanHistory) {
        scanHistoryDao.insertHistory(history)
    }

    suspend fun deleteById(id: Int) {
        scanHistoryDao.deleteHistoryById(id)
    }

    suspend fun clearAll() {
        scanHistoryDao.clearAllHistory()
    }
}
